# CONTENT-BASED-RECOMMENDATION-SYSTEMS
Login Page with Navigation to Sign-Up Page

<img width="1280" alt="Screenshot 2024-09-29 at 1 26 51 PM" src="https://github.com/user-attachments/assets/333565e9-36fa-46ff-b062-a6ea7cb78bc8">

Sign-Up Page for User Account Creation

<img width="1280" alt="Screenshot 2024-09-29 at 1 42 00 PM" src="https://github.com/user-attachments/assets/82d38685-aba8-4305-bcc0-cfcf91ca3697">
<img width="1280" alt="Screenshot 2024-09-29 at 1 42 08 PM" src="https://github.com/user-attachments/assets/2a92a3f3-5a71-43bf-8340-08011d0f6c67">

Forgot Password and Password Reset Pages
<img width="1280" alt="Screenshot 2024-09-29 at 1 42 18 PM" src="https://github.com/user-attachments/assets/f4c18d51-86e9-4619-9c00-f4ecc27f0131">
<img width="1280" alt="Screenshot 2024-09-29 at 1 42 29 PM" src="https://github.com/user-attachments/assets/0dd6dea9-e4a3-49c7-9907-c93ef0129a50">

Movie Details:
<img width="1280" alt="Screenshot 2024-10-13 at 11 36 17 PM" src="https://github.com/user-attachments/assets/1434ee1e-c882-46a9-9eeb-24b7f3475f6f">
<img width="1280" alt="Screenshot 2024-10-13 at 11 36 27 PM" src="https://github.com/user-attachments/assets/cc016f76-e3b4-492c-b17c-8ecf03f4154c">
<img width="1280" alt="Screenshot 2024-10-13 at 11 36 36 PM" src="https://github.com/user-attachments/assets/bf00eb17-b710-4f59-afef-7635b5f704b5">
<img width="1280" alt="Screenshot 2024-10-13 at 11 36 50 PM" src="https://github.com/user-attachments/assets/1f722f6e-733f-4b1a-97b0-533fd4744f36">
<img width="1280" alt="Screenshot 2024-10-13 at 11 37 11 PM" src="https://github.com/user-attachments/assets/634cd40a-8508-4eed-b5ab-241202973480">

Film Profiles: Details of Actors, Famous Personalities, Directors, and Producers
<img width="1280" alt="Screenshot 2024-10-13 at 11 37 24 PM" src="https://github.com/user-attachments/assets/cd497c91-dac1-4b99-8acb-eecae437e8a6">
<img width="1280" alt="Screenshot 2024-10-13 at 11 37 35 PM" src="https://github.com/user-attachments/assets/1901ba0f-2c4b-4b5b-9771-30f7ad4b7ee3">
<img width="1280" alt="Screenshot 2024-10-13 at 11 37 43 PM" src="https://github.com/user-attachments/assets/ad0554eb-50b4-4b03-aa53-91b195d89d30">
<img width="1280" alt="Screenshot 2024-10-13 at 11 37 53 PM" src="https://github.com/user-attachments/assets/b90f1524-24fe-45d4-9839-ad835d5efda2">

Menu:
<img width="1280" alt="Screenshot 2024-10-13 at 11 37 59 PM" src="https://github.com/user-attachments/assets/3c6ec344-22c8-45f4-bb66-16baa5379bec">

<img width="706" alt="Screenshot 2024-10-13 at 11 38 38 PM" src="https://github.com/user-attachments/assets/accc2a4b-da17-4420-8ca0-558b9ac6c8a3">

<img width="706" alt="Screenshot 2024-10-13 at 11 38 47 PM" src="https://github.com/user-attachments/assets/843fdd42-8caa-4f26-a3cc-900667a5691c">
<img width="706" alt="Screenshot 2024-10-13 at 11 38 57 PM" src="https://github.com/user-attachments/assets/d6a50652-bd34-4653-87b1-f0728013f7e4">
<img width="706" alt="Screenshot 2024-10-13 at 11 39 10 PM" src="https://github.com/user-attachments/assets/5012313b-ae59-4155-9c7e-57c6ff9e026f">
<img width="706" alt="Screenshot 2024-10-13 at 11 39 18 PM" src="https://github.com/user-attachments/assets/a2c22ada-002b-4eb1-8029-210c13ba9d14">
